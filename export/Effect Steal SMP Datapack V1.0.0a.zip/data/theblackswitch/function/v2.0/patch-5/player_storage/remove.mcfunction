execute unless function theblackswitch:v2.0/patch-5/version_control/is_latest run return fail
$data remove storage theblackswitch:player_storage players[$(player_id)].$(path)
