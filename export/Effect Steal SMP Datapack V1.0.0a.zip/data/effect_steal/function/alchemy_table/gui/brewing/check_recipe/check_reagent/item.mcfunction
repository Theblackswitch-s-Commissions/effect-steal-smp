$return run execute if items block ~ ~ ~ container.2 $(id)
